from gendiff.gendiff_base import generate_diff

__all__ = ['generate_diff']
