ADDED = 'added'
CHANGED = 'changed'
REMOVED = 'removed'
NESTED = 'nested'
UNCHANGED = 'unchanged'
DEFAULT_INDENT = 4
FLAG_INDENT = 2
