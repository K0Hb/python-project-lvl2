from gendiff.format.stylish import to_stylish as stylish
from gendiff.format.plain import to_plain as plain
from gendiff.format.json import to_json as json

__all__ = ['stylish', 'plain', 'json']
